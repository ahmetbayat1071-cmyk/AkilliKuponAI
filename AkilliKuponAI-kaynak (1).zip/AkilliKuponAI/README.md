# Akıllı Kupon AI — Android başlangıç projesi

Bu paket, Android WebView içinde çalışan bir arayüz prototipi ve Android Studio proje iskeletidir. **Derlenmiş APK değildir.** Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için APK derlenemedi.

## Bu sürümde olanlar
- Mobil uyumlu Türkçe arayüz
- Minimum/maksimum oran filtreleri
- Bahis türü, risk profili, tarih ve sonuç sayısı kontrolleri
- Demo kayıtlar üzerinden filtreleme
- APK'ya çevrilebilecek Android Studio iskeleti

## Bilerek henüz olmayanlar
- Nesine canlı bağlantısı
- Gerçek fikstür/oran verisi
- Derin istatistik modeli ve kalibre edilmiş olasılıklar
- Gerçek kupon veya bahis işlemi

Demo maç adları ve oranlar gerçeğe ait değildir. Canlı sistem için Nesine'nin izin verdiği veri erişimi veya lisanslı bir veri sağlayıcısı gerekir. Gerçek maç istatistikleri, kadro haberleri ve oran geçmişi olmadan güvenilir olasılık iddia edilmemelidir.

## APK derleme
1. Android Studio'yu kurun (JDK 17 ve Android SDK API 35).
2. Bu klasörü Android Studio'da açın.
3. Gradle Sync tamamlandıktan sonra Build > Build APK(s) seçin.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

Bu proje bir başlangıç prototipidir; canlı veriye bağlanmadan gerçek bahis önerisi üretmek için kullanılmamalıdır.
