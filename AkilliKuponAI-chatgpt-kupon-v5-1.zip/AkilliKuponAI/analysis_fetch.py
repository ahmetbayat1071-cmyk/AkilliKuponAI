#!/usr/bin/env python3
"""Build a public, key-free API-Football deep-analysis snapshot.

Used by GitHub Actions. Does not create a home-grown probability model: published
1X2 probabilities (when available) are labeled as provider predictions only.
"""
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from zoneinfo import ZoneInfo

API_URL = "https://v3.football.api-sports.io"
KEY = os.environ.get("API_FOOTBALL_KEY", "")
IST = ZoneInfo("Europe/Istanbul")
MAX_MATCHES = 3
MAX_CALLS = 32  # Hard cap for user-triggered analysis, with daily quota protection.
CALLS = 0
CACHE = {}
FETCH_STATUS = {}
DAILY_REMAINING = None
ANALYSIS_VERSION = 2

# Competition-name filtering, not substring matching (to exclude U19 and lower divisions).
LEAGUES = {
    ("world", "uefa champions league"): 0,
    ("world", "uefa europa league"): 1,
    ("world", "uefa europa conference league"): 2,
    ("world", "uefa conference league"): 2,
    ("england", "premier league"): 10,
    ("spain", "la liga"): 11,
    ("italy", "serie a"): 12,
    ("germany", "bundesliga"): 13,
    ("france", "ligue 1"): 14,
    ("turkey", "süper lig"): 15,
    ("turkey", "super lig"): 15,
    ("portugal", "primeira liga"): 16,
    ("netherlands", "eredivisie"): 17,
    ("belgium", "jupiler pro league"): 18,
    ("scotland", "premiership"): 19,
    ("austria", "bundesliga"): 20,
    ("switzerland", "super league"): 21,
    ("greece", "super league 1"): 22,
    ("denmark", "superliga"): 23,
    ("norway", "eliteserien"): 24,
    ("sweden", "allsvenskan"): 25,
}


def priority(match):
    key = (str(match.get("country") or "").lower().strip(),
           str(match.get("league") or "").lower().strip())
    return LEAGUES.get(key, 999)


def parse_date(value):
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def api(endpoint, **params):
    """Get an API-Football list response, with non-secret endpoint diagnostics.

    An empty response is never silently described as evidence of no games.
    """
    global CALLS, DAILY_REMAINING
    token = (endpoint, tuple(sorted(params.items())))
    if token in CACHE:
        return CACHE[token]
    if CALLS >= MAX_CALLS or (DAILY_REMAINING is not None and DAILY_REMAINING <= 10):
        print("SKIPPED endpoint (local/daily safety quota):", endpoint)
        FETCH_STATUS[token] = "quota_guard"
        return []
    CALLS += 1
    url = API_URL + endpoint + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"x-apisports-key": KEY, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=24) as resp:
            limit = resp.headers.get("x-ratelimit-requests-remaining")
            if limit is not None:
                try:
                    DAILY_REMAINING = int(limit)
                except ValueError:
                    pass
            raw = resp.read(3_000_001)
            if len(raw) > 3_000_000:
                raise RuntimeError("API response larger than limit")
        data = json.loads(raw)
        if data.get("errors"):
            # Never reveal an API token in GitHub logs or public JSON.
            explanation = str(data["errors"]).replace(KEY, "[redacted]")[:350]
            print("API provider ERROR:", endpoint, explanation)
            FETCH_STATUS[token] = "provider_error"
            result = []
        else:
            result = data.get("response") or []
            if not isinstance(result, list):
                result = []
                FETCH_STATUS[token] = "unexpected_shape"
            else:
                FETCH_STATUS[token] = "ok" if result else "empty"
        print("API", endpoint, "status", FETCH_STATUS[token], "rows", len(result),
              "daily_remaining", DAILY_REMAINING if DAILY_REMAINING is not None else "unknown")
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, RuntimeError) as exc:
        print("API network/parse failure", endpoint, type(exc).__name__)
        FETCH_STATUS[token] = "request_failure"
        result = []
    CACHE[token] = result
    return result


def endpoint_status(endpoint, **params):
    return FETCH_STATUS.get((endpoint, tuple(sorted(params.items()))), "not_requested")


def find_match(m):
    try:
        id_ = int(m.get("id"))
        return id_ > 0
    except (ValueError, TypeError):
        return False


def selected_matches(snapshot):
    """Use only manually entered numeric fixture IDs in the public fixture list.

    No scheduled selection. Numbers are validated and the user cannot inject
    requests or change the endpoint through workflow inputs.
    """
    raw = os.environ.get("SELECTED_FIXTURE_IDS", "").strip()
    if not re.fullmatch(r"[0-9,\s]+", raw):
        raise SystemExit("Maç kimlikleri sadece sayı ve virgülden oluşmalıdır.")
    ids = [int(x) for x in re.split(r"[,\s]+", raw) if x]
    if not 1 <= len(ids) <= MAX_MATCHES or len(set(ids)) != len(ids) or any(i <= 0 for i in ids):
        raise SystemExit("Bir ile üç farklı maç kimliği yazmalısın. Örnek: 123456,123457")
    allowed = {int(m["id"]): m for m in snapshot.get("matches", [])
               if isinstance(m, dict) and find_match(m)}
    not_found = [i for i in ids if i not in allowed]
    if not_found:
        raise SystemExit("Bu kimlikler güncel maç listesinde bulunmuyor: " + ",".join(map(str, not_found)))
    return [allowed[i] for i in ids]


def score(f):
    goals = f.get("goals") or {}
    h, a = goals.get("home"), goals.get("away")
    return f"{h if h is not None else '—'}-{a if a is not None else '—'}"


def recent(teamid, upcoming_date, role, league_id=None, season=None):
    """Fetch real, *completed-before-kickoff* matches, trying safe fallbacks.

    The team+last endpoint can return no rows even for an established club due
    to provider access/season restrictions. This is not proof of no history.
    """
    base = {"count": 0, "rest_days": None, "games": [], "venue_split": {"count": 0}}
    try:
        tid = int(teamid)
    except (ValueError, TypeError):
        return base
    kick = parse_date(upcoming_date)
    if kick is None:
        return base
    if kick.tzinfo is None:
        kick = kick.replace(tzinfo=dt.timezone.utc)

    all_rows = []
    by_id = {}
    issues = []

    def gather(rows):
        for f in rows:
            fixture = f.get("fixture") or {}
            fid = fixture.get("id")
            if fid is not None:
                by_id[str(fid)] = f

    args = {"team": tid, "last": 10}
    gather(api("/fixtures", **args))
    if endpoint_status("/fixtures", **args) != "ok":
        issues.append("Takımın son maç sorgusu boş veya erişim hatalı")

    def completed_before_kickoff():
        selected = []
        for f in by_id.values():
            fixture = f.get("fixture") or {}
            stamp = parse_date(fixture.get("date"))
            if not stamp or stamp >= kick:
                continue
            status = (fixture.get("status") or {}).get("short")
            if status not in ("FT", "AET", "PEN"):
                continue
            h = (f.get("teams") or {}).get("home") or {}
            a = (f.get("teams") or {}).get("away") or {}
            is_home = str(h.get("id")) == str(tid)
            is_away = str(a.get("id")) == str(tid)
            if not (is_home or is_away):
                continue
            gf = (f.get("goals") or {}).get("home" if is_home else "away")
            ga = (f.get("goals") or {}).get("away" if is_home else "home")
            if not isinstance(gf, int) or not isinstance(ga, int):
                continue
            selected.append({"date": fixture.get("date"),
                             "opponent": (a if is_home else h).get("name") or "?",
                             "opponent_id": (a if is_home else h).get("id"),
                             "score": score(f), "result": "G" if gf > ga else "B" if gf == ga else "M",
                             "goals_for": gf, "goals_against": ga, "is_home": is_home})
        selected.sort(key=lambda x: x["date"], reverse=True)
        return selected

    completed = completed_before_kickoff()
    # Where possible, recover this season's fixtures without needing older
    # history, and do not query unrelated leagues/teams.
    try:
        league = int(league_id)
        start_year = int(season)
    except (ValueError, TypeError):
        league, start_year = None, None

    if len(completed) < 5 and league and start_year:
        args2 = {"league": league, "season": start_year, "team": tid}
        gather(api("/fixtures", **args2))
        completed = completed_before_kickoff()
        if endpoint_status("/fixtures", **args2) != "ok":
            issues.append("Güncel lig sezonunda geçmiş maçlar erişilebilir değil")
    # Previous season may be outside the free plan: do not assume success.
    if len(completed) < 5 and league and start_year:
        args3 = {"league": league, "season": start_year - 1, "team": tid}
        gather(api("/fixtures", **args3))
        completed = completed_before_kickoff()
        if endpoint_status("/fixtures", **args3) != "ok":
            issues.append("Önceki sezon maçları plana dahil olmayabilir")

    def group_stats(rows):
        return {"count": len(rows), "wins": sum(g["result"] == "G" for g in rows),
                "draws": sum(g["result"] == "B" for g in rows),
                "losses": sum(g["result"] == "M" for g in rows),
                "goals_for": sum(g["goals_for"] for g in rows),
                "goals_against": sum(g["goals_against"] for g in rows)}

    last5 = completed[:5]
    stats = group_stats(last5)
    target = [g for g in completed if g["is_home"] == (role == "home")]
    stats["venue_split"] = group_stats(target[:5])
    stats["games"] = [{k: v for k, v in g.items() if k in ("date", "opponent", "score", "result")}
                      for g in last5]
    stats["rest_days"] = None
    if completed:
        previous = parse_date(completed[0]["date"])
        if previous:
            stats["rest_days"] = max(0, round((kick - previous).total_seconds() / 86400, 1))
    stats["data_status"] = "ok" if stats["count"] >= 5 else "partial" if stats["count"] else "unavailable"
    stats["data_notes"] = issues
    return stats


def injuries_for(fixture_id):
    data = api("/injuries", fixture=fixture_id)
    result, seen = [], set()
    for x in data[:80]:
        player = x.get("player") or {}
        team = x.get("team") or {}
        name = player.get("name")
        if not name:
            continue
        # The provider sometimes duplicates the same injury alert.
        key = (str(team.get("id") or team.get("name") or "").casefold(),
               str(player.get("id") or name).casefold(),
               str(player.get("type") or "").casefold(),
               str(player.get("reason") or "").casefold())
        if key in seen:
            continue
        seen.add(key)
        result.append({"player": name, "team": team.get("name") or "?",
                       "type": str(player.get("type") or "")[:100],
                       "reason": str(player.get("reason") or "")[:160]})
        if len(result) == 24:
            break
    return result


def lineups_for(fixture_id, home_id, away_id):
    data = api("/fixtures/lineups", fixture=fixture_id)
    result = {"home": {}, "away": {}}
    for item in data:
        team = item.get("team") or {}
        which = "home" if team.get("id") == home_id else "away" if team.get("id") == away_id else None
        if not which:
            continue
        start = [((p.get("player") or {}).get("name")) for p in item.get("startXI") or []]
        result[which] = {"formation": item.get("formation"),
                         "coach": (item.get("coach") or {}).get("name"),
                         "start_xi": [n for n in start if n][:11]}
    return result


def probability(value):
    if value is None:
        return None
    text = re.sub(r"[^0-9.]", "", str(value))
    try:
        num = float(text)
        return round(num, 1) if 0 <= num <= 100 else None
    except ValueError:
        return None


def predict(fixture_id):
    rows = api("/predictions", fixture=fixture_id)
    if not rows:
        return {"percent": {"home": None, "draw": None, "away": None}, "advice": ""}
    entry = rows[0].get("predictions") or {}
    perc = entry.get("percent") or {}
    advice = str(entry.get("advice") or "")[:300]
    return {"percent": {k: probability(perc.get(k)) for k in ("home", "draw", "away")},
            "advice": advice}


def h2h_for(homeid, awayid):
    if not homeid or not awayid:
        return []
    rows = api("/fixtures/headtohead", h2h=f"{homeid}-{awayid}", last=5)
    result = []
    for f in rows[:5]:
        result.append({"date": (f.get("fixture") or {}).get("date") or "",
                       "home": ((f.get("teams") or {}).get("home") or {}).get("name") or "?",
                       "away": ((f.get("teams") or {}).get("away") or {}).get("name") or "?",
                       "score": score(f)})
    return result


def combined_factors(home_form, away_form, injuries, lineups, venue, h2h):
    """Explain contextual evidence without pretending it is a calibrated probability."""
    factors = []
    nh, na = home_form.get("count", 0), away_form.get("count", 0)
    if nh >= 3 and na >= 3:
        home_ppg = (3 * home_form["wins"] + home_form["draws"]) / nh
        away_ppg = (3 * away_form["wins"] + away_form["draws"]) / na
        if home_ppg - away_ppg > 0.5:
            factors.append("Son maç puan ortalamasında ev sahibi önde: %.2f - %.2f puan/maç; rakip gücü düzeltilmedi." % (home_ppg, away_ppg))
        elif away_ppg - home_ppg > 0.5:
            factors.append("Son maç puan ortalamasında deplasman takımı önde: %.2f - %.2f puan/maç; rakip gücü düzeltilmedi." % (away_ppg, home_ppg))
        else:
            factors.append("Son maç puan ortalamaları birbirine yakın (ev %.2f; dep %.2f); bu tek başına güvenilir sonuç göstergesi değildir." % (home_ppg, away_ppg))
    else:
        factors.append("Takımların son maç verisi yeterli olmadığından form üstünlüğü çıkarılmadı.")
    home_split = home_form.get("venue_split") or {}
    away_split = away_form.get("venue_split") or {}
    if home_split.get("count", 0) >= 2 and away_split.get("count", 0) >= 2:
        hs = 3 * home_split.get("wins", 0) + home_split.get("draws", 0)
        as_ = 3 * away_split.get("wins", 0) + away_split.get("draws", 0)
        factors.append("İç/dış saha örneklemi: ev sahibi %d maçta %d puan, konuk ekip deplasmanda %d maçta %d puan (son 10 maç içinden)." %
                       (home_split["count"], hs, away_split["count"], as_))
    else:
        factors.append("İç saha ve deplasman karşılaştırması için yeterli maç örneği bulunamadı.")
    hr, ar = home_form.get("rest_days"), away_form.get("rest_days")
    if hr is not None and ar is not None:
        if abs(hr-ar) >= 2:
            factors.append("Dinlenme farkı: ev sahibi yaklaşık %s, deplasman yaklaşık %s gün. Yorgunluk açısından incelenmeli." % (hr, ar))
        else:
            factors.append("Dinlenme aralığı iki takım için de benzer: yaklaşık %s ve %s gün." % (hr, ar))
    else:
        factors.append("Dinlenme karşılaştırması için son maç tarihi eksik.")
    if venue.get("name"):
        factors.append("Stadyum bilgisi mevcut; saha avantajının büyüklüğü bağımsız olarak ölçülmedi.")
    else:
        factors.append("Stadyum doğrulanamadığı için saha koşulları etkisi değerlendirilemiyor.")
    if injuries:
        factors.append("API'da %d oyuncu için eksik/şüpheli durumu bildirildi. Oyuncuların ilk 11 önemi ve kesin yokluk durumu bilinmeden sayısal etki atanmadı." % len(injuries))
    else:
        factors.append("API'da oyuncu eksikliği bildirilmedi; bu, eksik olmadığı anlamına gelmez.")
    if (lineups.get("home") or {}).get("start_xi") and (lineups.get("away") or {}).get("start_xi"):
        factors.append("İki takımın bildirilen ilk 11'i mevcut; dizilişler kadro bölümünde karşılaştırılabilir.")
    else:
        factors.append("İlk 11'ler tam değil. Resmi kadrolar belli olmadan kadro avantajı varsayılmadı.")
    factors.append("Önceki karşılaşma kaydı: %d; geçmiş eşleşmeler tek başına güçlü tahmin kanıtı değildir." % len(h2h))
    return factors


def build():
    if not KEY:
        raise SystemExit("API_FOOTBALL_KEY GitHub secret missing")
    source = Path("data/fixtures.json")
    if not source.is_file():
        raise SystemExit("Run fixture updater first to create data/fixtures.json")
    fixture_snapshot = json.loads(source.read_text(encoding="utf-8"))
    selected = selected_matches(fixture_snapshot)
    print("Manually selected matches:", ",".join(str(x["id"]) for x in selected))

    dest = Path("data/analysis.json")
    try:
        previous = json.loads(dest.read_text(encoding="utf-8")) if dest.is_file() else {}
        existing = previous.get("matches", {})
        if not isinstance(existing, dict):
            existing = {}
    except (ValueError, OSError):
        existing = {}

    now = dt.datetime.now(dt.timezone.utc)
    # Do not charge a second request for the same event analyzed in past 18h.
    retained = {}
    active_ids = {str(m.get("id")) for m in fixture_snapshot.get("matches", []) if isinstance(m, dict)}
    for fixture_id, record in existing.items():
        if fixture_id in active_ids and isinstance(record, dict):
            retained[fixture_id] = record
    chosen_for_fetch = []
    for m in selected:
        current = retained.get(str(m["id"]))
        timestamp = parse_date(current.get("analyzed_at")) if current else None
        if timestamp and timestamp.tzinfo and current.get("analysis_version") == ANALYSIS_VERSION and now - timestamp < dt.timedelta(hours=18):
            print("Already analyzed recently; use cache:", m["id"])
        else:
            chosen_for_fetch.append(m)

    details = {}
    if chosen_for_fetch:
        ids = "-".join(str(m["id"]) for m in chosen_for_fetch)
        for item in api("/fixtures", ids=ids):
            fixture = item.get("fixture") or {}
            if fixture.get("id"):
                details[str(fixture["id"])] = item

    for original in chosen_for_fetch:
        fixture_id = int(original["id"])
        item = details.get(str(fixture_id)) or {}
        fixture = item.get("fixture") or {}
        teams = item.get("teams") or {}
        home = teams.get("home") or {}
        away = teams.get("away") or {}
        homeid, awayid = home.get("id"), away.get("id")
        venue = fixture.get("venue") or {}
        print("Analyzing selected fixture:", fixture_id)
        prediction = predict(fixture_id)
        injuries = injuries_for(fixture_id)
        lineups = lineups_for(fixture_id, homeid, awayid)
        league_info = item.get("league") or {}
        home_form = recent(homeid, original.get("utc"), "home", league_info.get("id"), league_info.get("season"))
        away_form = recent(awayid, original.get("utc"), "away", league_info.get("id"), league_info.get("season"))
        h2h = h2h_for(homeid, awayid)
        warnings = []
        if not (lineups.get("home", {}).get("start_xi") and lineups.get("away", {}).get("start_xi")):
            warnings.append("Her iki takımın ilk 11'i henüz tam doğrulanmadı; kadro etkisi nicel tahmine yansıtılmadı.")
        if not injuries:
            warnings.append("API'da eksik oyuncu kaydı yok; bu, sakat veya cezalı oyuncu bulunmadığı anlamına gelmez.")
        if home_form.get("count", 0) < 5 or away_form.get("count", 0) < 5:
            warnings.append("Takımlardan en az birinin son beş maç verisi tam değil.")
        if all(v is None for v in prediction["percent"].values()):
            warnings.append("Tahmin olasılıkları API-Football tarafından bu maç için sağlanmadı.")
        for role, form in (("Ev sahibi", home_form), ("Deplasman", away_form)):
            if form.get("rest_days") is not None and form["rest_days"] < 3:
                warnings.append(role + " takımın son maçından itibaren dinlenme süresi 3 günün altında.")
        warnings.append("Stat ve maç saati değişebilir; hava durumu, seyahat ve oyuncu etkisi bağımsız modelde ölçülmedi.")
        factors = combined_factors(home_form, away_form, injuries, lineups, venue, h2h)
        if not h2h:
            factors[-1] = "Bu API planında geçmiş eşleşmeler listelenemedi; bu, takımların daha önce karşılaşmadığı anlamına gelmez."
        for label, form in (("Ev sahibi", home_form), ("Deplasman", away_form)):
            if form.get("count", 0) < 5:
                warnings.append(label + " son maçları eksik. Sonuçlar bilinmiyor; sıfır galibiyet olarak yorumlanmamalı.")
                warnings.extend(label + ": " + x for x in form.get("data_notes", [])[:2])
        if not venue.get("name"):
            warnings.append("Maçın oynanacağı stadyum API'de doğrulanmadı; ev sahibi kulübün stadı varsayılmadı.")
        retained[str(fixture_id)] = {
            "analysis_version": ANALYSIS_VERSION,
            "home": original.get("home") or home.get("name") or "?",
            "away": original.get("away") or away.get("name") or "?",
            "day": original.get("day"), "utc": original.get("utc"),
            "country": original.get("country"), "league": original.get("league"),
            "venue": {"name": venue.get("name"), "city": venue.get("city")},
            "prediction": prediction, "injuries": injuries, "lineups": lineups,
            "form": {"home": home_form, "away": away_form},
            "h2h": h2h, "factors": factors, "warnings": warnings,
            "analyzed_at": dt.datetime.now(dt.timezone.utc).isoformat()
        }
        time.sleep(0.15)

    payload = {"generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
               "source": "API-Football", "selection_mode": "manual", "analysis_version": ANALYSIS_VERSION,
               "fixtures_generated_at": fixture_snapshot.get("generated_at"),
               "description": "Provider predictions not independently validated; missing data is unknown, not zero risk",
               "matches": retained}
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(dest)
    print("Snapshot written; public entries:", len(retained), "API calls this run:", CALLS, "daily remaining:", DAILY_REMAINING)


if __name__ == "__main__":
    build()
