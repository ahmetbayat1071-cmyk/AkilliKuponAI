# Akıllı Kupon AI — ChatGPT derin analiz ve kupon V5.1

V5 sürümünü temel alan bu yapı, seçilen 1-3 maçı ChatGPT’ye gönderirken **her maç için bahis tercihi, daha temkinli alternatif ve uygunsa en fazla iki maçlık ortak kupon** da talep eder. Güvenilir veri yetersizse 'kupona alma' veya 'kupon yapma' sonucuna izin verir.

- Maçlar GitHub’daki veri dosyasından gelir.
- Bağımsız tahmin motoru değildir; ChatGPT sohbetinde kullanıcı gönderince web araştırması yapılabilir.
- ChatGPT'nin araştırma yeteneği ve normal kullanım limitleri geçerlidir. Ek OpenAI API ücreti kullanılmaz.
- Canlı bahiste oranlar doğrulanmadıysa herhangi bir oran veya kazanma yüzdesi uydurulmaz.
- Başlamış/bitmiş maçlara geçmişe yönelik ön maç kuponu önerilmez.
- Bu uygulama önceki V5'in yanına ayrı bir uygulama olarak kurulur; eskisini silme.

Kurulum: `AkilliKuponAI-chatgpt-kupon-v5-1.zip` dosyasını deponun ana klasörüne, `android-chatgpt-kupon-v5-1.yml` dosyasını `.github/workflows/` klasörüne yükle.
