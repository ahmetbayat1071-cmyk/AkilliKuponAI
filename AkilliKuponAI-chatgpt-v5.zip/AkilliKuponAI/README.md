# Akıllı Kupon AI — ChatGPT Paylaşım V5

Bu proje V4 maç seçim ekranına **"Seçili maçları ChatGPT ile analiz et"**
özelliği ekler. Önce maçları seç, sonra düğmeye bas. Uygulama seçilen maçın
isimlerini, ligini, başlama saatini, maç kimliğini ve dikkatli bir araştırma
isteğini hazırlar. Android bu metni panoya kopyalar ve mümkünse ChatGPT
uygulamasına **paylaşım niyeti (ACTION_SEND, text/plain)** ile aktarır.
ChatGPT paylaşım arayüzü sürüme göre desteklenmeyebilir: o durumda ChatGPT
web sayfası açılır ve kullanıcı yapıştırır. **Mesaj otomatik gönderilmez.**

- **OpenAI API kullanılmaz.** ChatGPT normal hesap/plan sınırlarıyla çalışır.
- ChatGPT düğmesi `API_FOOTBALL_KEY` içermez, API-Football kotası tüketmez.
- GitHub üzerinden isteğe bağlı önceki derin analiz özelliği korunur.
- Gerçek maç programı herkese açık `data/fixtures.json` dosyasından gelir.
- Analiz araştırmasının eksik bilgi ve doğrulama koşulları istekte açıklanır.
- İnternet üzerinden veri aramak ChatGPT uygulamasındaki yeteneklere bağlıdır.
- Bu uygulama otomatik veri arayan bir ChatGPT API istemcisi değildir.
- Kazanma garantisi, Nesine oranı veya doğrulanmış bahis modeli sunmaz.

## GitHub Actions ile APK

`AkilliKuponAI-chatgpt-v5.zip` deposun ana klasörüne,
`android-chatgpt-v5.yml` ise `.github/workflows/` altına yüklenir.
Yeni APK, ayrı uygulama kimliği sayesinde V4'ün yanına kurulabilir.
