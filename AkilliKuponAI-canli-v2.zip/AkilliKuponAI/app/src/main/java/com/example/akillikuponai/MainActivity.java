package com.example.akillikuponai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    // Public snapshot only. The secret API key stays in GitHub Actions.
    private static final String FIXTURES_URL =
        "https://raw.githubusercontent.com/ahmetbayat1071-cmyk/AkilliKuponAI/main/data/fixtures.json";
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Controls(), "Fixtures");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith("file:///android_asset/")) fetchFixtures();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Controls {
        @JavascriptInterface public void refresh() { fetchFixtures(); }
    }

    private void fetchFixtures() {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(FIXTURES_URL).openConnection();
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Cache-Control", "no-cache");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    throw new IllegalStateException("Veri dosyası henüz hazır değil (HTTP " + connection.getResponseCode() + ")");
                }
                ByteArrayOutputStream data = new ByteArrayOutputStream();
                try (InputStream stream = connection.getInputStream()) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = stream.read(buffer)) != -1) {
                        if (data.size() + read > 3_000_000) throw new IllegalStateException("Veri boyutu çok büyük");
                        data.write(buffer, 0, read);
                    }
                }
                String payload = data.toString(StandardCharsets.UTF_8.name());
                new JSONObject(payload); // Verify snapshot before passing it to JavaScript.
                runOnUiThread(() -> web.evaluateJavascript("window.renderLiveSnapshot(" + JSONObject.quote(payload) + ");", null));
            } catch (Exception error) {
                String msg = (error.getMessage() == null) ? "Bağlantı hatası" : error.getMessage();
                runOnUiThread(() -> web.evaluateJavascript("window.renderLiveError(" + JSONObject.quote(msg) + ");", null));
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }
}
