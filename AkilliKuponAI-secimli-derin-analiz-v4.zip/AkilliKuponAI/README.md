# Akıllı Kupon AI — Seçimli derin analiz V4

Bu proje kullanıcıya **en fazla 3 maç seçtirir**. Güvenli servis olmadan
mobil uygulama kendi kendine GitHub Actions çalıştıramaz: “Analiz ettir”
düğmesi seçilen maç ID'lerini telefona kopyalar ve GitHub Actions iş akışını açar.

GitHub → Actions → "Secilen Maclari Derin Analiz Et" → "Run workflow" →
"selected_fixture_ids" alanına numaraları yapıştır → "Run workflow".
İşlem yeşil tik olunca Android'de "Yenile" → "Derin analizi aç".

API anahtarı **sadece** GitHub Secret (`API_FOOTBALL_KEY`) üzerinden kullanılır.
İş akışı sadece manuel tetiklenir, otomatik veya planlı çalışmaz.
Bir çalıştırma en fazla 3 maç inceler, yaklaşık 1+6×3 API isteği yapabilir.
Her maçın sonucu 18 saat saklanır. Sonuçlar herkese açık `data/analysis.json`
dosyasında yayınlanır (API anahtarı içermez). API-Football her maç için aynı
veri türlerini sağlamayabilir.

Bağımsız eğitilmiş/doğrulanmış yapay zekâ tahmini, Nesine oranı, otomatik kupon,
kesin başarı garantisi **yoktur**. Olasılık varsa sağlayıcı tahmini olarak
etiketlenir. Belirsizlikler ve kaynak eksikleri açıkça belirtilir.
