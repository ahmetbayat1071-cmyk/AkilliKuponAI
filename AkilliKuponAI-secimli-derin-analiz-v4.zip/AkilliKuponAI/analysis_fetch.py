#!/usr/bin/env python3
"""Build a public, key-free API-Football deep-analysis snapshot.

Used by GitHub Actions. Does not create a home-grown probability model: published
1X2 probabilities (when available) are labeled as provider predictions only.
"""
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from zoneinfo import ZoneInfo

API_URL = "https://v3.football.api-sports.io"
KEY = os.environ.get("API_FOOTBALL_KEY", "")
IST = ZoneInfo("Europe/Istanbul")
MAX_MATCHES = 3
MAX_CALLS = 22  # Max three matches, approx. 1 + 3*6 API requests (reuse endpoint cache).
CALLS = 0
CACHE = {}

# Competition-name filtering, not substring matching (to exclude U19 and lower divisions).
LEAGUES = {
    ("world", "uefa champions league"): 0,
    ("world", "uefa europa league"): 1,
    ("world", "uefa europa conference league"): 2,
    ("world", "uefa conference league"): 2,
    ("england", "premier league"): 10,
    ("spain", "la liga"): 11,
    ("italy", "serie a"): 12,
    ("germany", "bundesliga"): 13,
    ("france", "ligue 1"): 14,
    ("turkey", "süper lig"): 15,
    ("turkey", "super lig"): 15,
    ("portugal", "primeira liga"): 16,
    ("netherlands", "eredivisie"): 17,
    ("belgium", "jupiler pro league"): 18,
    ("scotland", "premiership"): 19,
    ("austria", "bundesliga"): 20,
    ("switzerland", "super league"): 21,
    ("greece", "super league 1"): 22,
    ("denmark", "superliga"): 23,
    ("norway", "eliteserien"): 24,
    ("sweden", "allsvenskan"): 25,
}


def priority(match):
    key = (str(match.get("country") or "").lower().strip(),
           str(match.get("league") or "").lower().strip())
    return LEAGUES.get(key, 999)


def parse_date(value):
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def api(endpoint, **params):
    """Return [] for missing/error data. Never print credentials or raw error URLs."""
    global CALLS
    token = (endpoint, tuple(sorted(params.items())))
    if token in CACHE:
        return CACHE[token]
    if CALLS >= MAX_CALLS:
        print("Daily safety budget reached; skipping another endpoint.")
        return []
    CALLS += 1
    url = API_URL + endpoint + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"x-apisports-key": KEY, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=24) as resp:
            raw = resp.read(3_000_001)
            if len(raw) > 3_000_000:
                raise RuntimeError("API response larger than limit")
        data = json.loads(raw)
        if data.get("errors"):
            print("Provider returned an endpoint error for", endpoint, "(data omitted).")
            result = []
        else:
            result = data.get("response") or []
            if not isinstance(result, list):
                result = []
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, RuntimeError) as exc:
        print("Provider unavailable for", endpoint, "-", type(exc).__name__)
        result = []
    CACHE[token] = result
    return result


def find_match(m):
    try:
        id_ = int(m.get("id"))
        return id_ > 0
    except (ValueError, TypeError):
        return False


def selected_matches(snapshot):
    """Use only manually entered numeric fixture IDs in the public fixture list.

    No scheduled selection. Numbers are validated and the user cannot inject
    requests or change the endpoint through workflow inputs.
    """
    raw = os.environ.get("SELECTED_FIXTURE_IDS", "").strip()
    if not re.fullmatch(r"[0-9,\s]+", raw):
        raise SystemExit("Maç kimlikleri sadece sayı ve virgülden oluşmalıdır.")
    ids = [int(x) for x in re.split(r"[,\s]+", raw) if x]
    if not 1 <= len(ids) <= MAX_MATCHES or len(set(ids)) != len(ids) or any(i <= 0 for i in ids):
        raise SystemExit("Bir ile üç farklı maç kimliği yazmalısın. Örnek: 123456,123457")
    allowed = {int(m["id"]): m for m in snapshot.get("matches", [])
               if isinstance(m, dict) and find_match(m)}
    not_found = [i for i in ids if i not in allowed]
    if not_found:
        raise SystemExit("Bu kimlikler güncel maç listesinde bulunmuyor: " + ",".join(map(str, not_found)))
    return [allowed[i] for i in ids]


def score(f):
    goals = f.get("goals") or {}
    h, a = goals.get("home"), goals.get("away")
    return f"{h if h is not None else '—'}-{a if a is not None else '—'}"


def recent(teamid, upcoming_id, role):
    try:
        tid = int(teamid)
    except (ValueError, TypeError):
        return {"count": 0, "rest_days": None, "games": [], "venue_split": {"count": 0}}
    matches = api("/fixtures", team=tid, last=10)
    completed = []
    for f in matches:
        status = ((f.get("fixture") or {}).get("status") or {}).get("short")
        if status not in ("FT", "AET", "PEN"):
            continue
        fixture = f.get("fixture") or {}
        stamp = parse_date(fixture.get("date"))
        if stamp is not None and stamp > dt.datetime.now(dt.timezone.utc):
            continue
        h = (f.get("teams") or {}).get("home") or {}
        a = (f.get("teams") or {}).get("away") or {}
        is_home = h.get("id") == tid
        gf = (f.get("goals") or {}).get("home" if is_home else "away")
        ga = (f.get("goals") or {}).get("away" if is_home else "home")
        if not isinstance(gf, int) or not isinstance(ga, int):
            continue
        completed.append({"date": fixture.get("date") or "", "opponent": (a if is_home else h).get("name") or "?",
                          "score": score(f), "result": "G" if gf > ga else "B" if gf == ga else "M",
                          "goals_for": gf, "goals_against": ga, "is_home": is_home})
    completed.sort(key=lambda a: a["date"], reverse=True)

    def group_stats(group):
        return {"count": len(group), "wins": sum(g["result"] == "G" for g in group),
                "draws": sum(g["result"] == "B" for g in group),
                "losses": sum(g["result"] == "M" for g in group),
                "goals_for": sum(g["goals_for"] for g in group),
                "goals_against": sum(g["goals_against"] for g in group)}

    last5 = completed[:5]
    stats = group_stats(last5)
    target = [g for g in completed if g["is_home"] == (role == "home")]
    stats["venue_split"] = group_stats(target[:5])
    stats["games"] = [{k: v for k, v in g.items() if k in ("date", "opponent", "score", "result")}
                       for g in last5]
    stats["rest_days"] = None
    kick = parse_date(upcoming_id)
    if kick and completed:
        previous = parse_date(completed[0]["date"])
        if previous:
            stats["rest_days"] = max(0, round((kick - previous).total_seconds() / 86400, 1))
    return stats


def injuries_for(fixture_id):
    data = api("/injuries", fixture=fixture_id)
    result = []
    for x in data[:24]:
        player = x.get("player") or {}
        team = x.get("team") or {}
        name = player.get("name")
        if name:
            result.append({"player": name, "team": team.get("name") or "?",
                           "type": str(player.get("type") or "")[:100],
                           "reason": str(player.get("reason") or "")[:160]})
    return result


def lineups_for(fixture_id, home_id, away_id):
    data = api("/fixtures/lineups", fixture=fixture_id)
    result = {"home": {}, "away": {}}
    for item in data:
        team = item.get("team") or {}
        which = "home" if team.get("id") == home_id else "away" if team.get("id") == away_id else None
        if not which:
            continue
        start = [((p.get("player") or {}).get("name")) for p in item.get("startXI") or []]
        result[which] = {"formation": item.get("formation"),
                         "coach": (item.get("coach") or {}).get("name"),
                         "start_xi": [n for n in start if n][:11]}
    return result


def probability(value):
    if value is None:
        return None
    text = re.sub(r"[^0-9.]", "", str(value))
    try:
        num = float(text)
        return round(num, 1) if 0 <= num <= 100 else None
    except ValueError:
        return None


def predict(fixture_id):
    rows = api("/predictions", fixture=fixture_id)
    if not rows:
        return {"percent": {"home": None, "draw": None, "away": None}, "advice": ""}
    entry = rows[0].get("predictions") or {}
    perc = entry.get("percent") or {}
    advice = str(entry.get("advice") or "")[:300]
    return {"percent": {k: probability(perc.get(k)) for k in ("home", "draw", "away")},
            "advice": advice}


def h2h_for(homeid, awayid):
    if not homeid or not awayid:
        return []
    rows = api("/fixtures/headtohead", h2h=f"{homeid}-{awayid}", last=5)
    result = []
    for f in rows[:5]:
        result.append({"date": (f.get("fixture") or {}).get("date") or "",
                       "home": ((f.get("teams") or {}).get("home") or {}).get("name") or "?",
                       "away": ((f.get("teams") or {}).get("away") or {}).get("name") or "?",
                       "score": score(f)})
    return result


def combined_factors(home_form, away_form, injuries, lineups, venue, h2h):
    """Explain contextual evidence without pretending it is a calibrated probability."""
    factors = []
    nh, na = home_form.get("count", 0), away_form.get("count", 0)
    if nh >= 3 and na >= 3:
        home_ppg = (3 * home_form["wins"] + home_form["draws"]) / nh
        away_ppg = (3 * away_form["wins"] + away_form["draws"]) / na
        if home_ppg - away_ppg > 0.5:
            factors.append("Son maç puan ortalamasında ev sahibi önde: %.2f - %.2f puan/maç; rakip gücü düzeltilmedi." % (home_ppg, away_ppg))
        elif away_ppg - home_ppg > 0.5:
            factors.append("Son maç puan ortalamasında deplasman takımı önde: %.2f - %.2f puan/maç; rakip gücü düzeltilmedi." % (away_ppg, home_ppg))
        else:
            factors.append("Son maç puan ortalamaları birbirine yakın (ev %.2f; dep %.2f); bu tek başına güvenilir sonuç göstergesi değildir." % (home_ppg, away_ppg))
    else:
        factors.append("Takımların son maç verisi yeterli olmadığından form üstünlüğü çıkarılmadı.")
    home_split = home_form.get("venue_split") or {}
    away_split = away_form.get("venue_split") or {}
    if home_split.get("count", 0) >= 2 and away_split.get("count", 0) >= 2:
        hs = 3 * home_split.get("wins", 0) + home_split.get("draws", 0)
        as_ = 3 * away_split.get("wins", 0) + away_split.get("draws", 0)
        factors.append("İç/dış saha örneklemi: ev sahibi %d maçta %d puan, konuk ekip deplasmanda %d maçta %d puan (son 10 maç içinden)." %
                       (home_split["count"], hs, away_split["count"], as_))
    else:
        factors.append("İç saha ve deplasman karşılaştırması için yeterli maç örneği bulunamadı.")
    hr, ar = home_form.get("rest_days"), away_form.get("rest_days")
    if hr is not None and ar is not None:
        if abs(hr-ar) >= 2:
            factors.append("Dinlenme farkı: ev sahibi yaklaşık %s, deplasman yaklaşık %s gün. Yorgunluk açısından incelenmeli." % (hr, ar))
        else:
            factors.append("Dinlenme aralığı iki takım için de benzer: yaklaşık %s ve %s gün." % (hr, ar))
    else:
        factors.append("Dinlenme karşılaştırması için son maç tarihi eksik.")
    if venue.get("name"):
        factors.append("Stadyum bilgisi mevcut; saha avantajının büyüklüğü bağımsız olarak ölçülmedi.")
    else:
        factors.append("Stadyum doğrulanamadığı için saha koşulları etkisi değerlendirilemiyor.")
    if injuries:
        factors.append("API'da %d oyuncu için eksik/şüpheli durumu bildirildi. Oyuncuların ilk 11 önemi ve kesin yokluk durumu bilinmeden sayısal etki atanmadı." % len(injuries))
    else:
        factors.append("API'da oyuncu eksikliği bildirilmedi; bu, eksik olmadığı anlamına gelmez.")
    if (lineups.get("home") or {}).get("start_xi") and (lineups.get("away") or {}).get("start_xi"):
        factors.append("İki takımın bildirilen ilk 11'i mevcut; dizilişler kadro bölümünde karşılaştırılabilir.")
    else:
        factors.append("İlk 11'ler tam değil. Resmi kadrolar belli olmadan kadro avantajı varsayılmadı.")
    factors.append("Önceki karşılaşma kaydı: %d; geçmiş eşleşmeler tek başına güçlü tahmin kanıtı değildir." % len(h2h))
    return factors


def build():
    if not KEY:
        raise SystemExit("API_FOOTBALL_KEY GitHub secret missing")
    source = Path("data/fixtures.json")
    if not source.is_file():
        raise SystemExit("Run fixture updater first to create data/fixtures.json")
    fixture_snapshot = json.loads(source.read_text(encoding="utf-8"))
    selected = selected_matches(fixture_snapshot)
    print("Manually selected matches:", ",".join(str(x["id"]) for x in selected))

    dest = Path("data/analysis.json")
    try:
        previous = json.loads(dest.read_text(encoding="utf-8")) if dest.is_file() else {}
        existing = previous.get("matches", {})
        if not isinstance(existing, dict):
            existing = {}
    except (ValueError, OSError):
        existing = {}

    now = dt.datetime.now(dt.timezone.utc)
    # Do not charge a second request for the same event analyzed in past 18h.
    retained = {}
    active_ids = {str(m.get("id")) for m in fixture_snapshot.get("matches", []) if isinstance(m, dict)}
    for fixture_id, record in existing.items():
        if fixture_id in active_ids and isinstance(record, dict):
            retained[fixture_id] = record
    chosen_for_fetch = []
    for m in selected:
        current = retained.get(str(m["id"]))
        timestamp = parse_date(current.get("analyzed_at")) if current else None
        if timestamp and timestamp.tzinfo and now - timestamp < dt.timedelta(hours=18):
            print("Already analyzed recently; use cache:", m["id"])
        else:
            chosen_for_fetch.append(m)

    details = {}
    if chosen_for_fetch:
        ids = "-".join(str(m["id"]) for m in chosen_for_fetch)
        for item in api("/fixtures", ids=ids):
            fixture = item.get("fixture") or {}
            if fixture.get("id"):
                details[str(fixture["id"])] = item

    for original in chosen_for_fetch:
        fixture_id = int(original["id"])
        item = details.get(str(fixture_id)) or {}
        fixture = item.get("fixture") or {}
        teams = item.get("teams") or {}
        home = teams.get("home") or {}
        away = teams.get("away") or {}
        homeid, awayid = home.get("id"), away.get("id")
        venue = fixture.get("venue") or {}
        print("Analyzing selected fixture:", fixture_id)
        prediction = predict(fixture_id)
        injuries = injuries_for(fixture_id)
        lineups = lineups_for(fixture_id, homeid, awayid)
        home_form = recent(homeid, original.get("utc"), "home")
        away_form = recent(awayid, original.get("utc"), "away")
        h2h = h2h_for(homeid, awayid)
        warnings = []
        if not (lineups.get("home", {}).get("start_xi") and lineups.get("away", {}).get("start_xi")):
            warnings.append("Her iki takımın ilk 11'i henüz tam doğrulanmadı; kadro etkisi nicel tahmine yansıtılmadı.")
        if not injuries:
            warnings.append("API'da eksik oyuncu kaydı yok; bu, sakat veya cezalı oyuncu bulunmadığı anlamına gelmez.")
        if home_form.get("count", 0) < 5 or away_form.get("count", 0) < 5:
            warnings.append("Takımlardan en az birinin son beş maç verisi tam değil.")
        if all(v is None for v in prediction["percent"].values()):
            warnings.append("Tahmin olasılıkları API-Football tarafından bu maç için sağlanmadı.")
        for role, form in (("Ev sahibi", home_form), ("Deplasman", away_form)):
            if form.get("rest_days") is not None and form["rest_days"] < 3:
                warnings.append(role + " takımın son maçından itibaren dinlenme süresi 3 günün altında.")
        warnings.append("Stat ve maç saati değişebilir; hava durumu, seyahat ve oyuncu etkisi bağımsız modelde ölçülmedi.")
        factors = combined_factors(home_form, away_form, injuries, lineups, venue, h2h)
        retained[str(fixture_id)] = {
            "home": original.get("home") or home.get("name") or "?",
            "away": original.get("away") or away.get("name") or "?",
            "day": original.get("day"), "utc": original.get("utc"),
            "country": original.get("country"), "league": original.get("league"),
            "venue": {"name": venue.get("name"), "city": venue.get("city")},
            "prediction": prediction, "injuries": injuries, "lineups": lineups,
            "form": {"home": home_form, "away": away_form},
            "h2h": h2h, "factors": factors, "warnings": warnings,
            "analyzed_at": dt.datetime.now(dt.timezone.utc).isoformat()
        }
        time.sleep(0.15)

    payload = {"generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
               "source": "API-Football", "selection_mode": "manual",
               "fixtures_generated_at": fixture_snapshot.get("generated_at"),
               "description": "Provider predictions not independently validated; missing data is unknown, not zero risk",
               "matches": retained}
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(dest)
    print("Snapshot written; public entries:", len(retained), "API calls this run:", CALLS)


if __name__ == "__main__":
    build()
