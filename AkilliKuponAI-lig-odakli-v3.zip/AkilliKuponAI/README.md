# Akıllı Kupon AI Canlı v0.2

Android için gerçek maç programını gösteren deneme sürümüdür.

- GitHub üzerindeki herkese açık `data/fixtures.json` adresinden **API-Football maç programı** alınır.
- Kullanıcı bugün/yarın seçebilir, takım/lig arayabilir ve listeyi yenileyebilir.
- Gizli API anahtarı Android APK içinde bulunmaz; yalnızca GitHub Actions veri yenileme işleminde kullanılır.
- Oran filtreleri halen **DEMO** bölümündedir. Nesine bahis oranları, olasılık hesaplaması veya kupon önerisi henüz yoktur.
- Veri canlı skor akışı değildir; kaynağın GitHub'da en son güncellenme zamanı gösterilir.
- Fikstür kaynağı: https://github.com/ahmetbayat1071-cmyk/AkilliKuponAI/blob/main/data/fixtures.json

Derleme: Java 17, Gradle 8.7, Android SDK 35, `gradle assembleDebug`.

Eski demo uygulama ile birlikte kurulabilmesi için uygulama kimliği `com.example.akillikuponai.live` olarak ayrılmıştır.

> Hiçbir bahis kesin kazanç garantisi vermez.

## v3 lig önceliği
Varsayılan görünüm yalnızca UEFA büyük kupaları ve seçilen ülkelerin üst liglerini gösterir. Tüm ligler seçeneği geçmiş görünümü sunar. Bahis oranı veya tahmin üretilmez.
